extends Node3D

const BALL_START := Vector3(0, 0.22, 4.2)
const GOAL_Z := -8.0
const GOAL_HALF_WIDTH := 3.65
const GOAL_HEIGHT := 2.45

var ball: RigidBody3D
var keeper: Node3D
var aim_marker: MeshInstance3D
var shot_count := 0
var goals := 0
var coins := 0
var phase := "ready"
var aim_x := 0.0
var aim_y := 1.35
var power := 18.0
var keeper_direction := 1.0
var shot_timer := 0.0

var hud: CanvasLayer
var score_label: Label
var message_label: Label
var power_bar: ProgressBar
var shoot_button: Button
var restart_button: Button

func _ready() -> void:
    _build_world()
    _build_ui()
    _reset_ball()
    _set_message("AIM YOUR SHOT  •  FIVE ATTEMPTS")

func _process(delta: float) -> void:
    if phase == "ready":
        keeper.position.x += keeper_direction * delta * 1.8
        if keeper.position.x > 2.2 or keeper.position.x < -2.2:
            keeper_direction *= -1.0
        aim_marker.position = Vector3(aim_x, aim_y, GOAL_Z + 0.08)
    elif phase == "flying":
        shot_timer += delta
        if ball.global_position.z < GOAL_Z - 0.8 or shot_timer > 3.0:
            _finish_shot()

func _build_world() -> void:
    var world_env := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.035, 0.07, 0.10)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.72, 0.78, 0.82)
    env.ambient_light_energy = 0.7
    world_env.environment = env
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-52, -25, 0)
    sun.light_energy = 1.4
    add_child(sun)

    _make_box("Pitch", Vector3(13, 0.25, 27), Vector3(0, -0.15, -1.5), Color(0.08, 0.42, 0.19))
    for i in range(9):
        var stripe_color = Color(0.09, 0.46, 0.21) if i % 2 == 0 else Color(0.07, 0.39, 0.17)
        _make_box("GrassStripe", Vector3(13, 0.012, 1.5), Vector3(0, -0.015, 10.0 - i * 3.0), stripe_color)
    _make_box("GoalBack", Vector3(7.5, 2.6, 0.12), Vector3(0, 1.3, -8.15), Color(0.82, 0.88, 0.9, 0.18), true)
    _make_box("Crossbar", Vector3(7.5, 0.12, 0.12), Vector3(0, 2.5, -8), Color.WHITE)
    _make_box("LeftPost", Vector3(0.12, 2.5, 0.12), Vector3(-3.7, 1.25, -8), Color.WHITE)
    _make_box("RightPost", Vector3(0.12, 2.5, 0.12), Vector3(3.7, 1.25, -8), Color.WHITE)
    _make_box("PenaltySpot", Vector3(0.35, 0.025, 0.35), Vector3(0, 0.0, 4.2), Color.WHITE)

    for x in [-2.8, -1.4, 0.0, 1.4, 2.8]:
        _make_box("NetLine", Vector3(0.025, 2.3, 0.025), Vector3(x, 1.2, -8.05), Color(0.72, 0.8, 0.82))
    for y in [0.4, 0.9, 1.4, 1.9, 2.4]:
        _make_box("NetLine", Vector3(7.3, 0.025, 0.025), Vector3(0, y, -8.05), Color(0.72, 0.8, 0.82))

    keeper = Node3D.new()
    keeper.position = Vector3(0, 0, -7.15)
    add_child(keeper)
    _make_box_child(keeper, "KeeperBody", Vector3(0.85, 1.15, 0.38), Vector3(0, 1.0, 0), Color(0.95, 0.48, 0.08))
    _make_box_child(keeper, "KeeperHead", Vector3(0.42, 0.42, 0.42), Vector3(0, 1.82, 0), Color(0.82, 0.62, 0.43))
    _make_box_child(keeper, "KeeperArms", Vector3(1.55, 0.22, 0.28), Vector3(0, 1.35, 0), Color(0.95, 0.48, 0.08))
    _make_box_child(keeper, "KeeperLegs", Vector3(0.72, 0.55, 0.34), Vector3(0, 0.3, 0), Color(0.08, 0.12, 0.18))

    ball = RigidBody3D.new()
    ball.name = "Football"
    ball.mass = 0.45
    ball.gravity_scale = 0.7
    ball.continuous_cd = true
    var sphere := SphereMesh.new()
    sphere.radius = 0.22
    sphere.height = 0.44
    var ball_mesh := MeshInstance3D.new()
    ball_mesh.mesh = sphere
    var ball_mat := StandardMaterial3D.new()
    ball_mat.albedo_color = Color(0.96, 0.96, 0.9)
    ball_mat.roughness = 0.35
    ball_mesh.material_override = ball_mat
    ball.add_child(ball_mesh)
    var shape := CollisionShape3D.new()
    var sphere_shape := SphereShape3D.new()
    sphere_shape.radius = 0.22
    shape.shape = sphere_shape
    ball.add_child(shape)
    add_child(ball)

    var marker_mesh := SphereMesh.new()
    marker_mesh.radius = 0.12
    marker_mesh.height = 0.24
    aim_marker = MeshInstance3D.new()
    aim_marker.mesh = marker_mesh
    var marker_mat := StandardMaterial3D.new()
    marker_mat.albedo_color = Color(1, 0.85, 0.15, 0.8)
    marker_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    aim_marker.material_override = marker_mat
    add_child(aim_marker)

    var camera := Camera3D.new()
    camera.position = Vector3(0, 5.3, 12.5)
    camera.rotation_degrees = Vector3(-17, 0, 0)
    camera.fov = 55
    add_child(camera)
    camera.current = true

func _make_box(label: String, size: Vector3, pos: Vector3, color: Color, transparent := false) -> void:
    var mesh := BoxMesh.new()
    mesh.size = size
    var node := MeshInstance3D.new()
    node.name = label
    node.mesh = mesh
    node.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA if transparent else BaseMaterial3D.TRANSPARENCY_DISABLED
    node.material_override = mat
    add_child(node)

func _make_box_child(parent: Node3D, label: String, size: Vector3, pos: Vector3, color: Color) -> void:
    var mesh := BoxMesh.new()
    mesh.size = size
    var node := MeshInstance3D.new()
    node.name = label
    node.mesh = mesh
    node.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    node.material_override = mat
    parent.add_child(node)

func _build_ui() -> void:
    hud = CanvasLayer.new()
    add_child(hud)
    var panel := ColorRect.new()
    panel.color = Color(0.015, 0.035, 0.055, 0.88)
    panel.position = Vector2(18, 18)
    panel.size = Vector2(684, 175)
    hud.add_child(panel)

    var title := Label.new()
    title.text = "LEGENDARY DISCO"
    title.position = Vector2(36, 25)
    title.add_theme_font_size_override("font_size", 42)
    title.add_theme_color_override("font_color", Color(1, 0.78, 0.12))
    hud.add_child(title)

    score_label = Label.new()
    score_label.position = Vector2(38, 82)
    score_label.add_theme_font_size_override("font_size", 25)
    hud.add_child(score_label)

    message_label = Label.new()
    message_label.position = Vector2(30, 220)
    message_label.size = Vector2(660, 70)
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.add_theme_font_size_override("font_size", 24)
    message_label.add_theme_color_override("font_color", Color(1, 0.9, 0.55))
    hud.add_child(message_label)

    power_bar = ProgressBar.new()
    power_bar.position = Vector2(110, 1000)
    power_bar.size = Vector2(500, 25)
    power_bar.min_value = 10
    power_bar.max_value = 30
    power_bar.value = power
    hud.add_child(power_bar)

    var power_label := Label.new()
    power_label.text = "SHOT POWER"
    power_label.position = Vector2(290, 965)
    power_label.add_theme_font_size_override("font_size", 19)
    hud.add_child(power_label)

    var left := Button.new()
    left.text = "◀ AIM"
    left.position = Vector2(35, 1080)
    left.size = Vector2(190, 90)
    left.add_theme_font_size_override("font_size", 25)
    left.pressed.connect(func(): _adjust_aim(-0.45, 0))
    hud.add_child(left)

    var right := Button.new()
    right.text = "AIM ▶"
    right.position = Vector2(495, 1080)
    right.size = Vector2(190, 90)
    right.add_theme_font_size_override("font_size", 25)
    right.pressed.connect(func(): _adjust_aim(0.45, 0))
    hud.add_child(right)

    shoot_button = Button.new()
    shoot_button.text = "SHOOT!"
    shoot_button.position = Vector2(250, 1060)
    shoot_button.size = Vector2(220, 115)
    shoot_button.add_theme_font_size_override("font_size", 32)
    shoot_button.add_theme_color_override("font_color", Color(0.05, 0.1, 0.08))
    shoot_button.add_theme_stylebox_override("normal", _button_style(Color(1, 0.78, 0.12)))
    shoot_button.pressed.connect(_shoot)
    hud.add_child(shoot_button)

    var up := Button.new()
    up.text = "AIM HIGHER"
    up.position = Vector2(260, 895)
    up.size = Vector2(200, 58)
    up.pressed.connect(func(): _adjust_aim(0, 0.35))
    hud.add_child(up)

    var down := Button.new()
    down.text = "AIM LOWER"
    down.position = Vector2(260, 1178)
    down.size = Vector2(200, 50)
    down.pressed.connect(func(): _adjust_aim(0, -0.25))
    hud.add_child(down)

    restart_button = Button.new()
    restart_button.text = "PLAY AGAIN"
    restart_button.position = Vector2(245, 720)
    restart_button.size = Vector2(230, 75)
    restart_button.visible = false
    restart_button.pressed.connect(_restart)
    hud.add_child(restart_button)

    var power_down := Button.new()
    power_down.text = "−"
    power_down.position = Vector2(35, 980)
    power_down.size = Vector2(60, 60)
    power_down.pressed.connect(func(): _change_power(-2))
    hud.add_child(power_down)
    var power_up := Button.new()
    power_up.text = "+"
    power_up.position = Vector2(625, 980)
    power_up.size = Vector2(60, 60)
    power_up.pressed.connect(func(): _change_power(2))
    hud.add_child(power_up)
    _update_score()

func _button_style(color: Color) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = color
    style.corner_radius_top_left = 18
    style.corner_radius_top_right = 18
    style.corner_radius_bottom_left = 18
    style.corner_radius_bottom_right = 18
    return style

func _adjust_aim(dx: float, dy: float) -> void:
    if phase != "ready":
        return
    aim_x = clamp(aim_x + dx, -3.25, 3.25)
    aim_y = clamp(aim_y + dy, 0.35, 2.3)
    _set_message("AIM • X: %.1f  HEIGHT: %.1f" % [aim_x, aim_y])

func _change_power(amount: float) -> void:
    if phase != "ready":
        return
    power = clamp(power + amount, 10, 30)
    power_bar.value = power

func _shoot() -> void:
    if phase != "ready":
        return
    shot_count += 1
    phase = "flying"
    shot_timer = 0.0
    ball.freeze = false
    ball.sleeping = false
    var direction := Vector3(aim_x * 0.105, (aim_y - 0.2) * 0.13, -1.0).normalized()
    ball.linear_velocity = direction * power
    ball.apply_torque_impulse(Vector3(2.0, 1.0, 0.8))
    shoot_button.disabled = true
    _set_message("LEGENDARY DISCO!  SHOT %d / 5" % shot_count)
    _update_score()

func _finish_shot() -> void:
    if phase != "flying":
        return
    var p := ball.global_position
    var scored := p.z <= GOAL_Z and abs(p.x) < GOAL_HALF_WIDTH - 0.2 and p.y > 0.15 and p.y < GOAL_HEIGHT
    var saved := abs(p.x - keeper.global_position.x) < 0.9 and p.y < 2.25
    if scored and not saved:
        goals += 1
        coins += 10
        _set_message("GOOOAL!  +10 COINS")
    elif scored and saved:
        _set_message("SAVED BY THE KEEPER!")
    else:
        _set_message("MISSED! ADJUST YOUR AIM")
    phase = "result"
    _update_score()
    await get_tree().create_timer(1.25).timeout
    if shot_count >= 5:
        phase = "finished"
        _set_message("FULL TIME  •  %d / 5 GOALS  •  %d COINS" % [goals, coins])
        restart_button.visible = true
    else:
        _reset_ball()

func _reset_ball() -> void:
    ball.freeze = true
    ball.global_position = BALL_START
    ball.linear_velocity = Vector3.ZERO
    ball.angular_velocity = Vector3.ZERO
    aim_x = 0.0
    aim_y = 1.35
    keeper.position.x = 0
    phase = "ready"
    shoot_button.disabled = false
    aim_marker.position = Vector3(aim_x, aim_y, GOAL_Z + 0.08)
    power_bar.value = power
    _update_score()

func _restart() -> void:
    shot_count = 0
    goals = 0
    restart_button.visible = false
    _reset_ball()
    _set_message("NEW CHALLENGE • FIVE SHOTS")

func _update_score() -> void:
    score_label.text = "GOALS  %d     SHOTS  %d/5     COINS  %d" % [goals, shot_count, coins]

func _set_message(value: String) -> void:
    message_label.text = value
